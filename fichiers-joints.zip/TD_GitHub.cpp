//Fonctions réalisées par l'étudiant 1 :










//Fonctions réalisées par l'étudiant 2 :










//Fonctions réalisées par l'étudiant 3 :
