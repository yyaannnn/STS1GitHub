//Fonctions à réaliser par l'étudiant 1
bool estMajeur(int age);

int exposant(int nbre, int exp);

float TVA(int prix);

int plusGrand(int a, int b, int c);

//Fonctions à réaliser par l'étudiant 2
bool estPair(int nb);

int sommeNombre(int nb);

float salaireNet(int salaire);

int plusPetit(int a, int b, int c);

//Fonctions à réaliser par l'étudiant 3
bool estImpair(int nb);

float moyenne(int nb1, int nb2, int nb3);

float reduction(int prix, int reduc);

int nombreMedian(int a, int b, int c);